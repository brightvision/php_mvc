/**
 * readme.txt
 *
 * @author Muhammad Imran Khan - imran.brightvision@gmail.com
 * @version 1.0
 * @date August 14, 2014
 */

Comment System:

Installation:

1. Import database i.e. comment_system.sql(inside root directory) OR open .sql file, copy the SQL source, then run the sql source in SQL Command Line.

2. Please open config.php located in root directory of the application. Enter appliction url, example:

define('APP_URL', 'http://localhost/comment_system');

* Please don't put forward slash end of the url.

3. Run this application in your browser.

4. Add Post -> View Post -> Write Comment.




Thank you.