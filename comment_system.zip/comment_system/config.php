<?php  
/** 
* Database credentials
*/
define ('DB_HOST', 	'localhost');
define ('DB_NAME', 	'comment_system');
define ('DB_USER', 	'root');
define ('DB_PASS', 	'');


/** 
* Application URL
* Please don't put forward slash end of the url.
*/
define ('APP_URL', 	'http://localhost/comment_system');